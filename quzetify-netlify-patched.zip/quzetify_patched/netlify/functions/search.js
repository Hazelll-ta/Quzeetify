export default async (req) => {
  const url = new URL(req.url);
  const query = url.searchParams.get('query') || '';
  const type = url.searchParams.get('type') || 'songs';

  if (!query) {
    return new Response(JSON.stringify({ status: false, message: 'Parameter query wajib diisi' }), {
      status: 400,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
    });
  }

  try {
    const upstreamUrl = `https://nanzz-music.netlify.app/.netlify/functions/search?query=${encodeURIComponent(query)}&type=${encodeURIComponent(type)}`;
    const upstreamRes = await fetch(upstreamUrl, {
      headers: {
        'Referer': 'https://nanzz-music.netlify.app',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      },
    });

    const data = await upstreamRes.text();
    return new Response(data, {
      status: upstreamRes.status,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
        'Cache-Control': 'public, max-age=60',
      },
    });
  } catch (err) {
    return new Response(JSON.stringify({ status: false, error: err.message }), {
      status: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
    });
  }
};
