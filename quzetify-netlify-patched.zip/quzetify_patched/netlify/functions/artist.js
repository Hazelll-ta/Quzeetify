export default async (req) => {
  const url = new URL(req.url);
  const id = url.searchParams.get('id') || '';

  if (!id) {
    return new Response(JSON.stringify({ status: false, message: 'Parameter id wajib diisi' }), {
      status: 400,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
    });
  }

  try {
    const upstreamUrl = `https://nanzz-music.netlify.app/.netlify/functions/artist?id=${encodeURIComponent(id)}`;
    const upstreamRes = await fetch(upstreamUrl, {
      headers: {
        'Referer': 'https://nanzz-music.netlify.app',
      },
    });

    const data = await upstreamRes.text();
    return new Response(data, {
      status: upstreamRes.status,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
    });
  } catch (err) {
    return new Response(JSON.stringify({ status: false, error: err.message }), {
      status: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
    });
  }
};
