export default async (req) => {
  const url = new URL(req.url);
  const query = url.searchParams.get('query') || '';

  if (!query) {
    return new Response(JSON.stringify([]), {
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
    });
  }

  try {
    const upstreamUrl = `https://nanzz-music.netlify.app/.netlify/functions/suggest?query=${encodeURIComponent(query)}`;
    const upstreamRes = await fetch(upstreamUrl, {
      headers: {
        'Referer': 'https://nanzz-music.netlify.app',
      },
    });

    const data = await upstreamRes.text();
    return new Response(data, {
      status: upstreamRes.status,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
    });
  } catch (err) {
    return new Response(JSON.stringify([]), {
      status: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
    });
  }
};
