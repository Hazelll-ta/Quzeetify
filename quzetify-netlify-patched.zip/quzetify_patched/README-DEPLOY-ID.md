# Quzetify — Netlify (patched)

Paket ini mempertahankan UI/aset yang sudah ada. Perbaikan yang dilakukan:
- Struktur publik hasil build ditempatkan di `dist`, sesuai konfigurasi Netlify.
- Tombol Play/Pause pada kontrol media perangkat sekarang memeriksa status sebelum melakukan toggle.

## Deploy
Gunakan Netlify CLI atau hubungkan repositori Git ke Netlify agar folder `netlify/functions` ikut dipasang. Jangan unggah folder `dist` saja melalui drag-and-drop biasa, karena fungsi API serverless tidak ikut terpasang dengan cara itu.

Build settings di `netlify.toml`:
- Publish directory: `dist`
- Functions directory: `netlify/functions`
- Build command: kosong/tidak diperlukan; frontend sudah berupa hasil build.

## Batasan pemutaran latar belakang
Aplikasi web dapat melanjutkan audio saat layar mati pada browser/perangkat yang mendukungnya, tetapi tidak bisa dijamin selalu berjalan jika Android menghentikan browser/tab, mode hemat baterai membatasi aktivitas, koneksi putus, atau sumber audio eksternal berhenti/URL kedaluwarsa. Pemutaran latar belakang setara aplikasi musik native membutuhkan implementasi aplikasi Android dengan layanan media native.

## Ketergantungan eksternal
Fungsi pencarian, lirik, artis, dan stream audio meneruskan permintaan ke `nanzz-music.netlify.app`. Jika layanan itu berubah, membatasi akses, atau sedang tidak tersedia, fungsi terkait dapat gagal meskipun kode Quzetify benar.
